package member.board.dto;


import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MemDto {
	
	@NotNull(message="id is bull.")
	@NotEmpty(message = "id is empty.")
	private String id;
	
	@NotNull(message="password is bull.")
	@NotEmpty(message = "password is empty.")
	private String password;
	private String name;
	@DateTimeFormat(pattern = "yyyyMMdd")
	private Date birth;
	private String address;
	
	

}
