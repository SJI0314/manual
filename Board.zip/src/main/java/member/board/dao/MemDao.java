package member.board.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import member.board.dto.MemDto;

@Mapper
public interface MemDao {

	String idCheck(String id);
	int insertMem(MemDto dto);
	MemDto login(MemDto dto);
	int updateMem(MemDto dto);
	int deleteMem(String id);
	
	@Update("update mem set password = #{nwPw} where id = #{id} and name = #{name}")
	int updatePw(@Param("id") String id , @Param("name") String name, @Param("nwPw") String pw);
}
