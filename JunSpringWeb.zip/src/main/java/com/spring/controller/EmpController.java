package com.spring.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.spring.dto.Dept;
import com.spring.dto.Emp;
import com.spring.service.DeptService;
import com.spring.service.EmpService;

@Controller
public class EmpController {

	@Autowired
	EmpService eservice;
	
	@Autowired
	DeptService dservice;
	
	@GetMapping("/emp/form")//searchform
	public String form() {
		return "emp/form";
	}
	
	@GetMapping("/emp/searchresult")
	public String result(@ModelAttribute("ename") String ename, @ModelAttribute("job")String job, Model m) {
		
		List<Emp> elist = eservice.searchNameAndJob(ename, job);
		m.addAttribute("elist", elist);
		
		return "emp/result";
	}
	
	@GetMapping("search/dept") ///search/dept
	public String deptAll(Model m) {
		
		List<Dept> dlist = dservice.deptAll();
		m.addAttribute("dlist", dlist);
		
		return "emp/search";
	}
	
	@GetMapping("/search/emp/{deptno}")
	@ResponseBody
	public String empAll(@PathVariable("deptno") int deptno) {
		
		List<Map<String, Object>> elist = eservice.empAllDeptno(deptno);
		
		Gson gson = new Gson(); 
		return gson.toJson(elist);
	}
	@GetMapping("/search/one/{empno}")
	@ResponseBody
	public String empOne(@PathVariable("empno") int empno) {
		Emp emp = eservice.empOne(empno);
		
		Gson gson = new Gson();
		return gson.toJson(emp);
	}
	
}












