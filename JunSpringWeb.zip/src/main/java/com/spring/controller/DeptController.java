package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.spring.dto.Dept;
import com.spring.service.DeptService;

@Controller
public class DeptController {
	@Autowired
	DeptService dservice;
	
	@GetMapping("/deptAll")
	public String deptAll(Model m) {
		List<Dept> dlist = dservice.deptAll();
		m.addAttribute("deptAll",dlist);

		return "dept/deptAll";
	}	

	@GetMapping("/dept/form")
	public String form(Model m) {
		int num = dservice.num();
		m.addAttribute("num",num);
		return "/dept/form";
	}
	
	@PostMapping("/dept/insert")
	public String insert(Dept d , Model m) {
		int insert = dservice.insertDept(d);
		List<Dept> dlist = dservice.deptAll();
		m.addAttribute("deptAll",dlist);
		m.addAttribute("Dept",insert);
		
		return "/dept/result";
	}
}
