package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class HelloController {

	@GetMapping("/hello") //요청uri

	public String hello(Model m) { //Model은 항상 View에 전달된다.

		m.addAttribute("hello", "안녕, spring!");

		return "hello"; //View name 리턴 (JSP) 

	}

}