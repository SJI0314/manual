package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.command.NewArticleCommand;
import com.spring.service.ArticleService;


@Controller
@RequestMapping("/article/newArticle")
public class NewArticleController {
	
	@Autowired
	private ArticleService articleService;
	
	@GetMapping
	public String form() {
		return "article/newArticleForm";
	}
	@PostMapping
	public String submit(@ModelAttribute("command") NewArticleCommand command) {
		articleService.writeArticle(command);
		return "article/newArticleSubmit";
	}
	
	public void setArticleService(ArticleService articleService) {
		
		this.articleService = articleService;
		
	}
	
}
