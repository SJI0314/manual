package com.spring.controller;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.command.ReportCommand;


@Controller
public class ReportSubmissionController {
	
	@GetMapping("/report/submission")
	public String form() {
		
		return "report/submissionForm";
		
	}
	
	@PostMapping("/report/submitReport1")
	public String submitReport1(
			@RequestParam("studentNumber") String studentNumber ,
			@RequestParam("report") MultipartFile report
			) {
		
		printInfo(studentNumber,report);
		upload(report);
		return  "report/submissionComplete";
	}
	
	private void printInfo(String studentNumber, MultipartFile report) {
		System.out.println(studentNumber + "가 업로드 한 파일: " + report.getOriginalFilename());
	}
	
	private String makeFileName(String origName) {
		//ms+_random.확장자
		long currentTime = System.currentTimeMillis();
		Random random =new Random();
		int r = random.nextInt(50); // 0~49 랜덤발생
		int index = origName.lastIndexOf(".");
		String ext = origName.substring(index + 1);
		return currentTime+"_"+r+"."+ext;
	}
	
			// c:/upload폴더 생성
		private String upload(MultipartFile tempfile) {
			//파일에 upload 폴더로 이동 , 이동한 경로를 리턴
			String fileName = makeFileName(tempfile.getOriginalFilename());
			File newFile = new File("c:/upload/" + fileName);
			try {
				tempfile.transferTo(newFile);
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
			return newFile.getPath();
		}
	
		@PostMapping("/report/submitReport2")
		public String submitReport2(MultipartHttpServletRequest request,Model m) {
			//일반 파라미터 이름 = 값 
			String studentNumber = request.getParameter("studentNumber");
			MultipartFile report = request.getFile("report");
			printInfo(studentNumber,report);
			String path = request.getServletContext().getRealPath("/mainImg");
			String newFileName = makeFileName(report.getOriginalFilename());
			File newFile = new File(path , newFileName);
			
			try {
				report.transferTo(newFile);
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
			
			m.addAttribute("path",newFileName);
			
			return "report/submissionComplete";
		}
		
		//3번쨰 방법 resources 파일에 넣고 클라이언트가 볼 수 있게 작업한다.
		
		@PostMapping("report/submitReport3")
		public String submitReport3(ReportCommand Command , Model m) {
			
			String newFileName = makeFileName(Command.getReport().getOriginalFilename());
			File newFile = null;
			
			try {
			String path = ResourceUtils.getFile("classpath:static/upload/").toPath().toString();
			newFile = new File(path , newFileName);
			System.out.println(newFile.getPath());
			Command.getReport().transferTo(newFile);
			}catch(IOException | IllegalStateException e){
				e.printStackTrace();
			}
			
			if(newFile != null) {
				
				m.addAttribute("path" , newFileName);
			}
			return "report/submissionComplete";
		}		

}
