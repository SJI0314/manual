package com.spring.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.spring.dto.FileinfoDto;
import com.spring.service.FileinfoService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class UploadController {
	
	@Autowired
	FileinfoService service;
	
	@GetMapping("/filedownload/{fileid}")
	public void fileDownload(@PathVariable("fileid") int id, HttpServletResponse response, HttpServletRequest request) throws IOException {
	FileinfoDto dto = service.fileOne(id);
    String path = ResourceUtils.getFile("classpath:static").toPath().toString();
    File file = new File(path, dto.getPath());

    String fileName = new String(dto.getName().getBytes("utf-8"), "iso-8859-1");

    response.setContentType("application/octet-stream; charset=utf-8");
    response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");// 다운로드 받을 파일명 지정

    response.setHeader("Content-Transfer-Encoding", "binary");

    OutputStream out = response.getOutputStream();

    FileInputStream fis = null;
    try {
     fis = new FileInputStream(file);
     FileCopyUtils.copy(fis, out);
    } finally {
     if (fis != null)
        try {
           fis.close();
        } catch (IOException ex) {
        }
    }
    out.flush();
  
    }
	
	
	@GetMapping("/list")
	public String list(Model m) {
		List<FileinfoDto> fList = service.fileList();
		m.addAttribute("fList", fList);
		return "/file/list";
	}

	@GetMapping("/upload")
	public String form() {
		
		return "file/fileform";
	}
	
	@PostMapping("/upload")
	public String submit(@ModelAttribute("dto") FileinfoDto dto , 
			@RequestParam("file") MultipartFile file ) {
		System.out.println(dto.getDescription());
		System.out.println(file.getOriginalFilename());
		
		if (!file.getOriginalFilename().equals("")) {
			//upload
			String filename = upload(file); //업로드 된 파일 명
			//DB insert
			dto.setName(file.getOriginalFilename());
			dto.setPath("/upload/"+filename);
			dto.setFilesize(file.getSize());
			//model 파일 정보 추가
			
		
			service.insertFile(dto);
		}

		return "file/result";
	}
	
	private String makeFileName(String origName) {
		//ms+_random.확장자
		long currentTime = System.currentTimeMillis();
		Random random =new Random();
		int r = random.nextInt(50); // 0~49 랜덤발생
		int index = origName.lastIndexOf(".");
		String ext = origName.substring(index);
		return currentTime+"_"+r+ext;
	}
	
	private String upload(MultipartFile file) {
		String newFileName = makeFileName(file.getOriginalFilename());
		File newFile = null;
		
		try {
			String path = ResourceUtils.getFile("classpath:static/upload/").toPath().toString();
			newFile = new File(path , newFileName);
			System.out.println(newFile.getPath());
			file.transferTo(newFile);
			
			}catch(IOException | IllegalStateException e){
				e.printStackTrace();
			}
		
		return newFileName;
	}
}
