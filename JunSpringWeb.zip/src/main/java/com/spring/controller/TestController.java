package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.spring.command.TestCommand;

@Controller
public class TestController {
	
	@GetMapping("/test/form")
	public String form() {
		
		return "test/form";
		
	}

	@PostMapping("test/submit")
	public String submit(@ModelAttribute("test") TestCommand testcommmand) {
		/*
		 * if(testcommmand.getId() != "abcd") { System.out.println("유저가 아닙니다"); return
		 * "test/form"; }
		 */
		System.out.println("아이디 : " + testcommmand.getId());
		return "test/submit";
		
	}
	
	@GetMapping("/test/a")
	public String a() {

		return "test/a";
	}
		

	
}
