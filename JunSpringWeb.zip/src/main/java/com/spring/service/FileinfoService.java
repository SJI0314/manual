package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.FileinfoDao;
import com.spring.dto.FileinfoDto;

@Service
public class FileinfoService {
	
	@Autowired
	FileinfoDao dao;
	
		public FileinfoDto fileOne(int fileid) {
			return dao.fileOne(fileid);
		} 
	
	public int insertFile(FileinfoDto dto) {
		System.out.println("dto.getFileid() 전" + dto.getFileid());
		int x =dao.insertFile(dto);
		System.out.println("dto.getFileid() 후" + dto.getFileid());
		return x;
	}


	public List<FileinfoDto> fileList(){
		
		return dao.fileList();
	}

}
