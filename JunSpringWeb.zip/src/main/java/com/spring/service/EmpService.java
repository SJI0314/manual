package com.spring.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.EmpDao;
import com.spring.dto.Emp;

@Service
public class EmpService {
	
	@Autowired
	EmpDao dao;
	
	public Emp empOne(int empno) {
		return dao.empOne(empno);
	}
	
	public List<Map<String, Object>> empAllDeptno(int deptno){
		return dao.empAllDeptno(deptno);
	}
	
	
	//List<Emp> searchNameAndJob(Map<String, String> map); 
	public List<Emp> searchNameAndJob(String ename, String job){
		Map<String, String> map = new HashMap<>();
		map.put("ename", ename);
		map.put("job", job);
		
		return dao.searchNameAndJob(map);
		
	}
	
}
