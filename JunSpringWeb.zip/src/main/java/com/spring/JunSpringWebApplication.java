package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.filter.HiddenHttpMethodFilter;

@SpringBootApplication
@ComponentScan(basePackages = {"com.spring","com,example"}) //"com.spring" 기본 패키지도 다시 명시해줘야함
public class JunSpringWebApplication {
	public static void main(String[] args) {
		SpringApplication.run(JunSpringWebApplication.class, args);
	}
	@Bean
	public HiddenHttpMethodFilter hiddenHttpMethodFilter() {
	return new HiddenHttpMethodFilter();
	}

	// method라는 이름으로 전달된 값을 요청방식으로 인식한다.

}
