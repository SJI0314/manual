package com.spring.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.spring.dto.FileinfoDto;

@Mapper
public interface FileinfoDao {
	
	int insertFile(FileinfoDto dto);
	
	List<FileinfoDto>fileList();
	
	@Select("select *from fileinfo where fileid = #{fileid}")
	FileinfoDto fileOne(int fileid);


}
