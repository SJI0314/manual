package com.spring.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.spring.dto.Emp;

@Mapper
public interface EmpDao {
	@Select({"<script> select * from emp ",
	"<where>",
	"<if test=\"ename != '' \"> ename = #{ename} </if>",
	"<if test=\"job != '' \"> and job = #{job} </if>",
	"</where></script>"
	})
	List<Emp> searchNameAndJob(Map<String, String> map); 
	
	@Select("select empno, ename from emp where deptno = #{deptno}")
	List<Map<String, Object>> empAllDeptno(int deptno);
	
	@Select("select empno, ename, job, hiredate, dname as 'dept.dname', loc as 'dept.loc' "
			+ "from emp e inner join dept d on e.deptno = d.deptno "
			+ "where empno = #{empno}")
			Emp empOne(int empno);
	
	
	
}






